## Angular advanced course presentation
